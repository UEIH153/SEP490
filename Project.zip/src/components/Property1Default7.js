import "./Property1Default7.css";

const Property1Default7 = ({ group9950 }) => {
  return (
    <div className="property-1default7">
      <img className="property-1default-inner" alt="" src={group9950} />
    </div>
  );
};

export default Property1Default7;
